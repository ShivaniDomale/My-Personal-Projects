package com.example.WeatherMicroservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WeatherMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
